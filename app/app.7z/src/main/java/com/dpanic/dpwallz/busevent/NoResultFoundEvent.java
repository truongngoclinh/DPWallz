package com.dpanic.dpwallz.busevent;

/**
 * Created by dpanic on 11/8/2016.
 * Project: DPWallz
 */

public class NoResultFoundEvent {
}
