package com.dpanic.dpwallz.model;

import android.os.Parcel;
import android.os.Parcelable;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by dpanic on 9/29/2016.
 * Project: DPWallz
 */

public class Category extends RealmObject implements Parcelable {

//    static final String TABLE_NAME = "category";
//
//    private static final String FIELD_PKEY = "_id";
//    private static final String FIELD_NAME = "name";
//    private static final String FIELD_LINK = "link";
//
//    static final String CREATION_COMMAND =
//            "CREATE TABLE " + TABLE_NAME + " (" + FIELD_PKEY + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
//                    FIELD_NAME + " TEXT NOT NULL, " + FIELD_LINK + " LINK NOT NULL" + " )";
//    static final Func1<Cursor, Category> MAPPER = new Func1<Cursor, Category>() {
//        @Override
//        public Category call(Cursor cursor) {
//            return parseCursor(cursor);
//        }
//    };

    @PrimaryKey
    private String name;
    private String link;
    private String thumbLink;

    public Category(){}

    public Category(String name, String link, String thumbLink) {
        setName(name);
        setLink(link);
        setThumbLink(thumbLink);
    }

    protected Category(Parcel in) {
        name = in.readString();
        link = in.readString();
        thumbLink = in.readString();
    }

    public static final Creator<Category> CREATOR = new Creator<Category>() {
        @Override
        public Category createFromParcel(Parcel in) {
            return new Category(in);
        }

        @Override
        public Category[] newArray(int size) {
            return new Category[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    private void setLink(String link) {
        this.link = link;
    }

    public String getThumbLink() {
        return thumbLink;
    }

    public void setThumbLink(String thumbLink) {
        this.thumbLink = thumbLink;
    }

//    private static Category parseCursor(Cursor cursor) {
//        long id = DB.getLong(cursor, FIELD_PKEY);
//        String name = DB.getString(cursor, FIELD_NAME);
//        String link = DB.getString(cursor, FIELD_LINK);
//        return new Category(id, name, link);
//    }

//    static ContentValues toContentValues(Category category) {
//        ContentValues values = new ContentValues();
//        values.put(FIELD_NAME, category.getName());
//        values.put(FIELD_LINK, category.getLink());
//        return values;
//    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Category) {
            Category compareObj = (Category) obj;
            return compareObj.getName().equals(this.name);
        } else {
            return super.equals(obj);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(link);
        dest.writeString(thumbLink);
    }
}
