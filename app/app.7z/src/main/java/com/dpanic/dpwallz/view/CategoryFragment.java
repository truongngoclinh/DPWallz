package com.dpanic.dpwallz.view;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.dpanic.dpwallz.R;
import com.dpanic.dpwallz.control.HTMLParsingUtil;
import com.dpanic.dpwallz.model.Category;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.realm.Realm;
import io.realm.RealmResults;
import rx.Subscriber;

/**
 * Created by dpanic on 29/09/2016.
 * Project: DPWallz
 */

public class CategoryFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener{

    @BindView(R.id.category_container)
    SwipeRefreshLayout categoryContainer;

    @BindView(R.id.rv_category)
    RecyclerView rvCategory;

    @BindView(R.id.category_error_container)
    LinearLayout layoutError;

    ArrayList<Category> categoryList;
    private CategoryAdapter categoryAdapter;
    private Realm realm;
    private int orientation = Configuration.ORIENTATION_PORTRAIT;
    private GridLayoutManager layoutManager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_category_layout, container, false);
        ButterKnife.bind(this, fragmentView);
        return fragmentView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        initFragment();
    }

    private void initFragment() {
        categoryList = new ArrayList<>();

        realm = Realm.getDefaultInstance();

        categoryAdapter = new CategoryAdapter(getActivity(), categoryList);
        orientation = getActivity().getResources().getConfiguration().orientation;

        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            layoutManager = new GridLayoutManager(getActivity(), 2);
        } else {
            layoutManager = new GridLayoutManager(getActivity(), 3);
        }

        rvCategory.setAdapter(categoryAdapter);
        rvCategory.setLayoutManager(layoutManager);

        categoryContainer.setOnRefreshListener(this);
        categoryContainer.setColorSchemeColors(ContextCompat.getColor(getActivity(), R.color.colorAccent));
        categoryContainer.setRefreshing(true);

        loadCategoriesData();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        orientation = newConfig.orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            layoutManager.setSpanCount(2);
        } else {
            layoutManager.setSpanCount(3);
        }
    }

    private void loadCategoriesData() {
        if (realm.where(Category.class).findAll().size() > 0) {
            loadDataFromDB();
        } else {
            loadCategoryFromWebsite();
        }
    }

    private void loadDataFromDB() {
        realm.where(Category.class).findAll().asObservable().subscribe(new Subscriber<RealmResults<Category>>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onNext(RealmResults<Category> categories) {
                categoryList.clear();
                categoryList.addAll(categories);

                categoryAdapter.notifyDataSetChanged();
                rvCategory.setVisibility(View.VISIBLE);
                categoryContainer.setRefreshing(false);
            }
        });
//        subscription = mDataManager.getCategoryList().subscribe(new Action1<List<Category>>() {
//            @Override
//            public void call(List<Category> categories) {
//                Log.d("thanh.dao", "getCategoryList: size = " + categories.size());
//                if (subscription != null) {
//                    subscription.unsubscribe();
//                }
//                if (categories.size() > 0) {
//                    categoryList.clear();
//                    categoryList.addAll(categories);
//                    sortCategory(categoryList);
//                    categoryAdapter.notifyDataSetChanged();
//                    categoryContainer.setRefreshing(false);
//                } else {
//                    loadCategoryFromWebsite(false);
//                }
//            }
//        });
    }

    private void loadCategoryFromWebsite() {
        HTMLParsingUtil.getCategory().subscribe(new Subscriber<List<Category>>() {
            @Override
            public void onCompleted() {
            }

            @Override
            public void onError(Throwable e) {
            }

            @Override
            public void onNext(List<Category> categories) {
                categoryContainer.setRefreshing(false);

                addCategoriesToDB(categories);
                loadDataFromDB();
            }
        });
    }

//    private static void sortCategory(List<Category> list) {
//        Collections.sort(list, new Comparator<Category>() {
//            @Override
//            public int compare(Category cat1, Category cat2) {
//                return cat1.getName().compareTo(cat2.getName());
//            }
//        });
//    }

    private void addCategoriesToDB(List<Category> list) {
        realm.beginTransaction();
        realm.where(Category.class).findAll().deleteAllFromRealm();
        realm.copyToRealm(list);
        realm.commitTransaction();
    }

    @Override
    public void onRefresh() {
        Log.e("thanh.dao", "onRefresh: ");
        layoutError.setVisibility(View.GONE);
        loadCategoryFromWebsite();
    }

    @OnClick(R.id.category_btn_retry)
    void onClick() {
        categoryContainer.setRefreshing(true);
        onRefresh();
    }
}
