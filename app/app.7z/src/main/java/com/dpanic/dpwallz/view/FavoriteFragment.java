package com.dpanic.dpwallz.view;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;

import com.dpanic.dpwallz.R;
import com.dpanic.dpwallz.control.FileUtil;
import com.dpanic.dpwallz.model.Image;
import com.dpanic.dpwallz.util.Constants;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.realm.Realm;
import io.realm.RealmResults;
import rx.functions.Action1;

/**
 * Created by dpanic on 10/14/2016.
 * Project: DPWallz
 */

public class FavoriteFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {

    private ArrayList<Image> favList;
    private ArrayList<Image> displayList;

    @BindView(R.id.image_list_recycler_view)
    RecyclerView rvFavorite;

    @BindView(R.id.image_list_container)
    SwipeRefreshLayout refreshLayout;

//    @BindView(R.id.no_download_layout)
//    LinearLayout noDownloadLayout;
//
//    @BindView(R.id.no_fav_layout)
//    LinearLayout noFavLayout;

    @BindView(R.id.no_download_view_stub)
    ViewStub noDownloadViewStub;

    @BindView(R.id.no_fav_view_stub)
    ViewStub noFavViewStub;

    View noDownloadView;
    View noFavView;

    private ImageAdapter iaFavorite;
    private int totalItemCount;
    private int firstVisibleItem;
    private int visibleItemCount;
    private boolean isLoading = false;
    private int visibleThreshold = 5;
    private int setCount = 0;

    private static final int batchSize = 20;
    private boolean isFavorite;
    private Realm realm;

    public static FavoriteFragment getInstance(boolean isFavorite) {
        FavoriteFragment favoriteFragment = new FavoriteFragment();

        Bundle bundle = new Bundle();
        bundle.putBoolean(Constants.IS_FAVORITE_FRAGMENT, isFavorite);

        favoriteFragment.setArguments(bundle);

        return favoriteFragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View fragmentView = inflater.inflate(R.layout.fragment_image_list_layout, container, false);
        ButterKnife.bind(this, fragmentView);
        return fragmentView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Bundle bundle = getArguments();
        isFavorite = bundle.getBoolean(Constants.IS_FAVORITE_FRAGMENT);

        realm = Realm.getDefaultInstance();

        if (noDownloadView == null) {
            noDownloadView = noDownloadViewStub.inflate();
        }

        if (noFavView == null) {
            noFavView = noFavViewStub.inflate();
        }

        favList = new ArrayList<>();
        displayList = new ArrayList<>();
        iaFavorite = new ImageAdapter(getActivity(), displayList, !isFavorite);
        final GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2);
        rvFavorite.setAdapter(iaFavorite);
        rvFavorite.setLayoutManager(layoutManager);

        refreshLayout.setOnRefreshListener(this);
        refreshLayout.setColorSchemeColors(ContextCompat.getColor(getActivity(), R.color.colorAccent));
        refreshLayout.setRefreshing(true);

        rvFavorite.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    totalItemCount = layoutManager.getItemCount();
                    //                    pastVisibleItems = layoutManager.findLastVisibleItemPosition();
                    firstVisibleItem = layoutManager.findFirstVisibleItemPosition();
                    visibleItemCount = layoutManager.getChildCount();

                    if (!isLoading && (totalItemCount - visibleItemCount) <= (firstVisibleItem + visibleThreshold)) {
                        isLoading = true;
                        onLoadMore();
                    }
                }
            }
        });


        initData();
    }

    private void onLoadMore() {
        Handler handler = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                favList.add(null);
                iaFavorite.notifyItemInserted(favList.size() - 1);
            }
        };
        handler.post(runnable);

        addDataBatch(setCount);
    }

    private void addDataBatch(int setCount) {
        int nextSetCount = setCount + 1;
        int startIndex = setCount * batchSize;
        int endIndex = nextSetCount * batchSize;
        int favListSize = favList.size();

        for (int i = startIndex; i < endIndex && i < favListSize; i++) {
            displayList.add(favList.get(i));
        }

        iaFavorite.notifyDataSetChanged();
    }

    private void initData() {
        if (isFavorite) {
            realm.where(Image.class).equalTo("isFavorite", true).findAll().asObservable()
                    .subscribe(new Action1<RealmResults<Image>>() {
                        @Override
                        public void call(RealmResults<Image> images) {
                            if (noFavView != null) {
                                if (images.size() == 0) {
                                    noFavView.setVisibility(View.VISIBLE);
                                } else {
                                    noFavView.setVisibility(View.GONE);
                                }
                            }

                            processInitData(images);
                        }
                    });
        } else {
            realm.where(Image.class).notEqualTo("localLink", "").findAll().asObservable()
                    .subscribe(new Action1<RealmResults<Image>>() {
                        @Override
                        public void call(RealmResults<Image> images) {
                            if (noDownloadView != null) {
                                if (images.size() == 0) {
                                    noDownloadView.setVisibility(View.VISIBLE);
                                } else {
                                    noDownloadView.setVisibility(View.GONE);
                                }
                            }

                            processInitData(images);
                        }
                    });
        }
    }

    private void processInitData(List<Image> images) {
        setCount = 0;
        favList.clear();
        displayList.clear();
        refreshLayout.setRefreshing(false);

        if (!isFavorite) {
            realm.beginTransaction();
            for (Image image : images) {
                if (FileUtil.isFileExists(image.getLocalLink())) {
                    favList.add(image);
                } else {
                    realm.where(Image.class).equalTo("pexelId", image.getPexelId()).findAll().deleteAllFromRealm();
                }
            }
            realm.commitTransaction();
        } else {
            favList.addAll(images);
        }

        addDataBatch(setCount);
        setCount++;
    }

    @Override
    public void onRefresh() {
        setCount = 0;
        favList.clear();
        displayList.clear();
        initData();
    }
}
